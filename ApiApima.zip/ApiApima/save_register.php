<?php
        
   include("Connect.php");  
    


          $cu_id=$_POST["cu_id"]; 
       $cu_name =$_POST["cu_name"];
       
       $cu_mobile=$_POST["cu_mobile"];
      

       $cu_address= $_POST["cu_address"];
       $cu_email= $_POST["cu_email"];
       $cu_pw1= $_POST["cu_pw1"];
       $cu_pw2= $_POST["cu_pw2"];
    
        
        $ty= $_POST["ty"];
      
        
          
          
          if( $cu_id==="" || $cu_name==="" || $cu_mobile==="" || $cu_address==="" || $cu_pw1==="" || $cu_pw2==="" ){
              
              
          echo "0";
              
          }else{
              if($cu_pw1 !== $cu_pw2){
               echo "4";   
              }else{
              
             
                    
                    if($ty==="1"){
                        
                        $msg1 =" select * from customer   where item_id='".$cu_id."'  ";
                    $result1=$con->query($msg1);
                    if ($row1 = mysqli_fetch_array($result1)){
                          mysqli_query($con, "UPDATE customer set description='".$desc."',item_type='".$typ."',cat_id='".$cat_id."',status='".$sta."' where item_id='".$id."' ");

                          echo "2";  
                    }   else{    
              
          

            
                           
    

 
               echo "3";
                      
                      
                      
                  } 
               
                        
                    }else if($ty==="0"){
                    
                    
         $msg1 =" SELECT * FROM user where username='".$cu_id."'  ";
                    $result1=$con->query($msg1);
                    if ($row1 = mysqli_fetch_array($result1)){
                        
                          echo "1";  
                    }   else{    
              
          

  mysqli_query($con, "INSERT INTO user (username,name,mobile,address,password,email) VALUES ('".$cu_id."','".$cu_name."','".$cu_mobile."','".$cu_address."','".$cu_pw1."','".$cu_email."')");
 
               echo "2";
                      
                      
                      
                  } 
              
          }
              
              
           
          }
              
          }
         
       
        
        
        
        ?>