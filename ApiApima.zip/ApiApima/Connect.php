
        <?php

 $con = new mysqli('localhost','root','1234','apiapima','3307') or die('Connection Error');
 
 
?>