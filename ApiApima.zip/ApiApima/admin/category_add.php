
 <?php

include("../Connect.php");
?>  
<div class="container-fluid  dashboard-content">
               
              
                
             
                   
                    <div class="row">
                       
                         <div class="card">
                                    <h5 class="card-header">Recent Category</h5>
                                      <div class="card">
	                                <div class="campaign-table table-responsive">
	                                    <table class="table">
	                                        <thead>
	                                            <tr class="border-0">
	                                                <th class="border-0">Id</th>
	                                                <th class="border-0">Category Name</th>
	                                               
	                                                
	                                            </tr>
	                                        </thead>
	                                        <tbody>
	                                            
      
        <?php
                    $msg =" SELECT * FROM catogory   ";
                    $result=$con->query($msg);
                    while ($row = mysqli_fetch_array($result)){
                         echo '<tr>';
                         echo '<td>'.$row["idCatogory"].'</td>';
                         echo '<td>'.$row["description"].'</td>';
                       echo '</tr>';
                         
                    }
                    
                    ?>
                    



 
 
    
  
	                                            
                                                  
	                                            
	                                           
	                                        </tbody>
	                                    </table>
	                                </div>
	                            </div>
                                </div>
                   
                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">New Category Add</h5>
                                <div class="card-body">
                                   
                                       
                                        <div class="form-group row">
                                           
                                            <div class="col-9 col-lg-10">
                                             
                                                <input id="cat_name" type="text"  placeholder="Category Name" class="form-control" required>
                                            </div>
                                        </div>
                                      
                                        <div class="row pt-2 pt-sm-5 mt-1">
                                           
                                            <div class="col-sm-6 pl-0">
                                                <p class="text-right">
                                                    <button type="submit" class="btn btn-space btn-primary" onclick="save_catogery()">Add</button>
                                                    
                                                </p>
                                            </div>
                                        </div>
                                    
                                </div>
                            </div>
                        </div>
                       
                    </div>
                    
           
            </div>
          
        
  
    
