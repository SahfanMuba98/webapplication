

<?php
session_start();
include("../Connect.php");

?>
     
       
            <div class="container-fluid  dashboard-content">
                
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="page-header">
                            <h2 class="pageheader-title">Expense Add </h2>
                          
                            
                        </div>
                    </div>
              
                         <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                       
                            <div class="card">
                                <h5 class="card-header">Expense Add</h5>
                                <div class="card-body">
                                    
                                          <div class="form-group">
                                            
                                           
                                     <?php
                                     $max_id5=0;
           $msg5="select count(expenseid) as s from expense";
 $result5=$con->query($msg5);
 if ($row5 = mysqli_fetch_array($result5)){
      $max_id5=$row5["s"]+1;                  
                 
      echo '                                              <input readonly="" id="pri_id" style=" color: #004085; font-size: 20px; font-weight: bold;" type="number" value="'.$max_id5.'">
';
      
                    }
                                     
                                     ?>        
 
                                            
                                             
                                             
                                                
                                               
                                                
                                                </div>
                                        <div class="form-group">
                                        <label class="font-16">Category</label>
                                        <select class="form-control" id="pri_ca">
                                            <?php
                    $msg =" SELECT * FROM catogory ORDER by catogory.description  ";
                    $result=$con->query($msg);
                    while ($row = mysqli_fetch_array($result)){
                        
                         echo '<option>'.$row["description"].'</option>';
                    }
                    
                    ?>
                                            
                                        </select>
                                        

                                    </div>
                                       
                                      
                                        
                                         
                                       
                                             <div class="mb-3">
                                                    <label >Amount <span class="text-muted"></span></label>
                                                    
                                                    <input type="number" required="" class="form-control" id="pri_amou">
                                            
                                                </div>
                                    
                                </div>
                            </div>
                         
                         
                         </div>
                        
                        
                        
                        
                        
                        
                        
                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                            <div class="card">
                               
                                       
                                    
                                       <div class="row">
                                           
                                            <div>
                                                <p class="text-right">
                                                      <h1 id="msg11" style=" color: red; font-size: 22px;"></h1>
                                                    <button type="submit" class="btn btn-space btn-primary" onclick="save_price('0');">Add New Price</button>
                                                    <button type="submit" class="btn btn-space btn-primary" onclick="save_price('1');">Update Price</button>
                                                    <button class="btn btn-space btn-secondary" onclick=" priceset_load();">Cancel</button>
                                                </p>
                                            </div>
                                        </div>
                                   
                                </div>
                            </div>
                            
                            
                              
                            
                            
                        </div>
                         
                    </div>
                
            </div>
           
      
   
   

