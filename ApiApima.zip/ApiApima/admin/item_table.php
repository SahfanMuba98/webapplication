      <table class="table table-striped table-bordered first">
                                        <thead>
                                            <tr>
                                              <th>Expense Id</th>
                                                <th>Amount</th>
                                                <th>Date</th>
                                                <th>Category</th>
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            
   <?php
   session_start();
    include("../Connect.php");  
          $to=$_GET["to"]; 
       $from =$_GET["from"];
       
        $ses='0';
        if( isset($_SESSION['id'])){
    

      

        $ses=$_SESSION['id'];}
       
      
           
           $msg2 =" select * from expense INNER JOIN catogory on expense.Catogory_idCatogory=catogory.idCatogory where date between '".$to."' and '".$from."' and User_username='".$ses."'  ";
                    $result2=$con->query($msg2);
                    while ($row2 = mysqli_fetch_array($result2)){
                        
                    
                         echo '<tr>';
                       echo '<td>'.$row2["expenseid"].'</td>';
                          echo '<td>'.$row2["expenseAmount"].'</td>';
                          echo '<td>'.$row2["date"].'</td>';
                          echo '<td>'.$row2["description"].'</td>';
                         
                       
                         
                         
                         
                       echo '</tr>';
                         
                    }
           
       
   
                   
                    
                    ?>
  
     
   
                                            
                 
    
   
                                           
                                           
                                            
                                            
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                             <th>Expense Id</th>
                                                <th>Amount</th>
                                                <th>Date</th>
                                                <th>Category</th>
                                               
                                            </tr>
                                        </tfoot>
                                    </table>