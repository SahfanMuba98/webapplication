<?php
        
   include("../Connect.php");  
    
     
        
       $desc =$_POST["name"];
       
      
        
            
            
          //$fileName=$_FILES['pic']['it_id'];
          
          
          
          if($desc===""){
              
              
          echo "0";
              
          }else{
             
          

  mysqli_query($con, "INSERT INTO catogory (description) VALUES ('".$desc."')");
 
               echo "2";
                      
                      
               
              
          }
         
       
        
        
        
        ?>