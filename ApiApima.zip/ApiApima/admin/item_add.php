

<?php
session_start();
include("../Connect.php");

?>
     
       
            <div class="container-fluid  dashboard-content">
                
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="page-header">
                            <h2 class="pageheader-title">Income Add </h2>
                          
                            
                        </div>
                    </div>
              
                         <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                       
                            <div class="card">
                                <h5 class="card-header">Income Add</h5>
                                <div class="card-body">
                                    
                                          <div class="form-group">
                                            
                                           
                                     <?php
                                     $max_id5=0;
           $msg5="select count(incomeid) as s from income";
 $result5=$con->query($msg5);
 if ($row5 = mysqli_fetch_array($result5)){
      $max_id5=$row5["s"]+1;                  
                 
      echo '                                              <input readonly="" id="it_id" style=" color: #004085; font-size: 20px; font-weight: bold;" type="number" value="'.$max_id5.'">
';
      
                    }
                                     
                                     ?>        
 
                                            
                                             
                                             
                                                
                                               
                                                
                                                </div>
                                        <div class="form-group">
                                        <label class="font-16">Category</label>
                                        <select class="form-control" id="it_ca">
                                            <?php
                    $msg =" SELECT * FROM catogory ORDER by catogory.description  ";
                    $result=$con->query($msg);
                    while ($row = mysqli_fetch_array($result)){
                        
                         echo '<option>'.$row["description"].'</option>';
                    }
                    
                    ?>
                                            
                                        </select>
                                        

                                    </div>
                                       
                                      
                                        
                                         
                                       
                                             <div class="mb-3">
                                                    <label >Amount <span class="text-muted"></span></label>
                                                    
                                                    <input type="number" required="" class="form-control" id="it_des">
                                            
                                                </div>
                                    
                                </div>
                            </div>
                         
                         </div>
                        
                        
                        
                        
                        
                        
                        
                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                            <div class="card">
                              
                                <div class="card-body">
                                    
                                    
                                   
                                  
                                       <div class="row">
                                           
                                            <div>
                                                <p class="text-right">
                                                      <h1 id="msg11" style=" color: red; font-size: 22px;"></h1>
                                                    <button type="submit" class="btn btn-space btn-primary" onclick="add_item('0');">Add New Item</button>
                                                    <button type="submit" class="btn btn-space btn-primary" onclick="add_item('1');">Update Item</button>
                                                    <button class="btn btn-space btn-secondary" onclick=" item_add_load();">Cancel</button>
                                                </p>
                                            </div>
                                        </div>
                                   
                                </div>
                            </div>
                            
                            
                              
                            
                            
                        </div>
                         
                    </div>
                
              
                
            </div>
           
      
   
   