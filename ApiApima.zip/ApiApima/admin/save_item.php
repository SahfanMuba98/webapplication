

<?php
    session_start();
   include("../Connect.php");  
 
          $id=$_POST["it_id"]; 
       $desc =$_POST["it_des"];
       
     $d = date('Y-m-d', time());
      

       $cat= $_POST["it_cat"];
    
        
        $ty= $_POST["ty"];
           $ses='0';
        if( isset($_SESSION['id'])){
    

      

        $ses=$_SESSION['id'];}
          
          if( $id==="" || $desc===""){
              
              
          echo "0";
              
          }else{
              $cat_id="0";
              $msg ="SELECT * FROM catogory where description='".$cat."'";
                    $result=$con->query($msg);
                    if ($row = mysqli_fetch_array($result)){
                        
                         $cat_id=$row["idCatogory"];
                    }
                    
                    if($ty==="1"){
                        
                        $msg1 =" select * from income  INNER JOIN catogory on catogory.idCatogory=income.Catogory_idCatogory where incomeid='".$id."'  ";
                    $result1=$con->query($msg1);
                    if ($row1 = mysqli_fetch_array($result1)){
                          mysqli_query($con, "UPDATE income set incomeAmount='".$desc."',Catogory_idCatogory='".$cat_id."' where incomeid='".$id."' ");

                          echo "2";  
                    }   else{    
              
          

            
                           
    

 
               echo "3";
                      
                      
                      
                  } 
               
                        
                    }else{
                    
                    
         $msg1 =" SELECT * FROM income where incomeid='".$id."'  ";
                    $result1=$con->query($msg1);
                    if ($row1 = mysqli_fetch_array($result1)){
                        
                          echo "1";  
                    }   else{    
              
          

  mysqli_query($con, "INSERT INTO income (incomeid,incomeAmount,Catogory_idCatogory,date,User_username) VALUES ('".$id."','".$desc."','".$cat_id."','".$d."','".$ses."')");
 
               echo "2";
                      
                      
                      
                  } 
              
          }
              
              
           
          
              
          }
         
       
        
        
        
        ?>