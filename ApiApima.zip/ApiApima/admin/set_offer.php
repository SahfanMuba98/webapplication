

<?php
session_start();
include("../Connect.php");

?>
     
       
            <div class="container-fluid  dashboard-content">
                
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="page-header">
                            <h2 class="pageheader-title">Income Report </h2>
                          
                            
                        </div>
                    </div>
              
                        
                        
                        
                        
                        
                         
                    </div>
                
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                               
                                   <div class="card-body">
                                        <h3 class="font-16">Search By</h3>
                                        
                                        
                                <input class="form-control form-control-lg" type="date" placeholder="Search" aria-label="Date To" id="dateTo">

                                        <br>
                                        
                                        
                                        <input class="form-control form-control-lg" type="date" placeholder="Search" aria-label="Date From" id="dateFrom" onkeyup="offer_list();">

                                    </div>
                             
                            </div>
                        </div>
                <div id="tabnle_it">
                    
                <table class="table table-striped table-bordered first">
                                        <thead>
                                            <tr>
                                                <th>Income Id</th>
                                                <th>Amount</th>
                                                <th>Date</th>
                                                <th>Category</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            
   <?php
    $ses='0';
        if( isset($_SESSION['id'])){
    

      

        $ses=$_SESSION['id'];}
                    $msg2 =" select * from income INNER JOIN catogory on income.Catogory_idCatogory=catogory.idCatogory where User_username='".$ses."' ";
                    $result2=$con->query($msg2);
                    while ($row2 = mysqli_fetch_array($result2)){
                        
                    
                         echo '<tr>';
                         echo '<td>'.$row2["incomeid"].'</td>';
                          echo '<td>'.$row2["incomeAmount"].'</td>';
                          echo '<td>'.$row2["date"].'</td>';
                          echo '<td>'.$row2["description"].'</td>';
                       
                          
                       
                         
                      
                         
                       echo '</tr>';
                         
                    }
                    
                    ?>
  
     
   
                                            
                 
    
   
                                           
                                           
                                            
                                            
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Income Id</th>
                                                <th>Amount</th>
                                                <th>Date</th>
                                                <th>Category</th>
                                               
                                            </tr>
                                        </tfoot>
                                    </table>
                
                  
                   
                   
           
            </div>
            </div>
           
      
   
   

