<!doctype html>
<?php
session_start();
include("../Connect.php");

?>
<html lang="en">
 
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">

    <link rel="stylesheet" href="assets/vendor/fonts/material-design-iconic-font/css/materialdesignicons.min.css">
  
    <link rel="stylesheet" href="assets/vendor/fonts/flag-icon-css/flag-icon.min.css">
    <title>API APIMA</title>
</head>

<body>
    
    <div class="dashboard-main-wrapper">
       
        <div class="dashboard-header">
            <nav class="navbar navbar-expand-lg bg-white fixed-top">
                <a class="navbar-brand" href="../index.php">API APIMA</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse " id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto navbar-right-top">
                        <li class="nav-item">
                            <div id="custom-search" class="top-search-bar">
                                <input class="form-control" type="text" placeholder="Search..">
                            </div>
                        </li>
                        
                        
                        <li class="nav-item dropdown nav-user">
                            <a class="nav-link nav-user-img" href="#" id="navbarDropdownMenuLink2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="assets/images/avatar-1.jpg" alt="" class="user-avatar-md rounded-circle"></a>
                            <div class="dropdown-menu dropdown-menu-right nav-user-dropdown" aria-labelledby="navbarDropdownMenuLink2">
                                <div class="nav-user-info">
                                    <h5 class="mb-0 text-white nav-user-name">API APIMA </h5>
                                    <span class="status"></span><span class="ml-2">Available</span>
                                </div>
                                <a class="dropdown-item" href="#"><i class="fas fa-user mr-2"></i>Account</a>
                             
                                <a class="dropdown-item" href="#"><i class="fas fa-power-off mr-2"></i>Logout</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        
        <div class="nav-left-sidebar sidebar-dark">
            <div class="menu-list">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav flex-column">
                            <li class="nav-divider">
                                Menu
                            </li>
                            
                            
                            
                             <li class="nav-item">
                                <a class="nav-link" onclick="category_add();" style="cursor: pointer;" data-toggle="collapse" aria-expanded="false" data-target="#submenu-2" aria-controls="submenu-2"><i class="fa fa-fw "></i>Categories Add</a>
                                <div id="submenu-2" class="collapse submenu" style="">
                                    
                                </div>
                            </li>
                            
                             <li class="nav-item">
                                <a class="nav-link" onclick="item_add_load();" style="cursor: pointer;" data-toggle="collapse" aria-expanded="false" data-target="#submenu-2" aria-controls="submenu-2"><i class="fa fa-fw "></i>Income Add</a>
                                <div id="submenu-2" class="collapse submenu" style="">
                                    
                                </div>
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link" onclick="priceset_load();" style="cursor: pointer;" data-toggle="collapse" aria-expanded="false" data-target="#submenu-2" aria-controls="submenu-2"><i class="fa fa-fw "></i>Expense Add</a>
                                <div id="submenu-2" class="collapse submenu" style="">
                                    
                                </div>
                            </li>
                            
                             <li class="nav-item">
                                <a class="nav-link" onclick="set_offer_load();" style="cursor: pointer;" data-toggle="collapse" aria-expanded="false" data-target="#submenu-2" aria-controls="submenu-2"><i class="fa fa-fw "></i>Income Report</a>
                                <div id="submenu-2" class="collapse submenu" style="">
                                    
                                </div>
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link" onclick="pending_customerload();" style="cursor: pointer;" data-toggle="collapse" aria-expanded="false" data-target="#submenu-2" aria-controls="submenu-2"><i class="fa fa-fw "></i>Expense Report</a>
                                <div id="submenu-2" class="collapse submenu" style="">
                                    
                                </div>
                            </li>
                            
                           
                            
                           
                            
                   
                            
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
      
        <div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content ">
                
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <h2 class="pageheader-title">Dashboard </h2>
                                <p class="pageheader-text"></p>
                               
                            </div>
                        </div>
                    </div>
                 <div id="or_list"></div>
                </div>
           
            
            
            
            
            
         
            <div class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="">
                             Copyright © 2024 Concept. All rights reserved. Dashboard by <a href="#">HashCode Innovations</a>.
                        </div>
                      
                    </div>
                </div>
            </div>
           
        </div>
        
    </div>
    </div>
   
    <!-- jquery 3.3.1 -->
    <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <!-- bootstap bundle js -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <!-- slimscroll js -->
    <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
    <!-- main js -->
    <script src="assets/libs/js/main-js.js"></script>
    <!-- chart chartist js -->

    <script src="assets/libs/js/dashboard-ecommerce.js"></script>
    <script src="../js/reqest.js"></script>
</body>
 
</html>