<?php
        session_start();
   include("../Connect.php");  
    
     
          $id=$_POST["pri_id"]; 
       $act =$_POST["pri_ca"];
       
       $sel=$_POST["pri_amount"];
      

       $d = date('Y-m-d', time());
    
        
        $ty= $_POST["ty"];
        
        
              $ses='0';
        if( isset($_SESSION['id'])){
    

      

        $ses=$_SESSION['id'];}   
         
          
          if( $id==="" || $sel==="" || $act===""){
              
              
          echo "0";
              
          }else{
              
              $cat_id="0";
              $msg ="SELECT * FROM catogory where description='".$act."'";
                    $result=$con->query($msg);
                    if ($row = mysqli_fetch_array($result)){
                        
                         $cat_id=$row["idCatogory"];
                    }
                    
                    if($ty==="3"){
                        
                        $msg1 =" select * from item_add INNER JOIN set_price on item_add.item_id=set_price.item_id  where item_add.item_id='".$id."'  ";
                    $result1=$con->query($msg1);
                    if ($row1 = mysqli_fetch_array($result1)){
                          mysqli_query($con, "UPDATE set_price set real_price='".$act."',sel_price='".$sel."' where item_id='".$id."' ");

                          echo "2";  
                    }   else{    
              
          

            
                           
    

 
               echo "3";
                      
                      
                      
                  } 
               
                        
                    }else{
                    
                    
         $msg2 =" select * from expense  where expenseid='".$id."'  ";
                    $result2=$con->query($msg2);
                    if ($row2 = mysqli_fetch_array($result2)){
                        
                          echo "1";  
                    }   else{    
              
          

            
                           
    

  mysqli_query($con, "INSERT INTO expense (expenseid,expenseAmount,Catogory_idCatogory,date,User_username) VALUES ('".$id."','".$sel."','".$cat_id."','".$d."','".$ses."')");
 
               echo "2";
                      
                      
                      
                  } 
              
          }
              
              
           
          
              
          }
         
       
        
        
        
        ?>