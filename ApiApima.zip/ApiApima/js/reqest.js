/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function l(){
    
    alert("y");
   
   
    

    
}

function forget_pass(ty){
    
    var un="";
    var em="";
    if(ty==="1"){
       un=   document.getElementById("un").value;
    em=   document.getElementById("em").value;    
        
    }else{
        
        un=   document.getElementById("un1").value;
    em=   document.getElementById("em1").value;   
    }
 
    var para="un="+un+"&em="+em+"&ty="+ty;
   var req= new XMLHttpRequest();
   req.open("POST","reset_pw.php",true);
    req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
   req.send(para);
    
   req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText.trim();
              
              if(res==="0"){
                  window.top.location='../index.php';
              }else if(res==="1"){
              document.getElementById("worng_id").innerHTML="UserName or Email Not Match";
          }else if(res==="2"){
                          //document.getElementById("un1").innerHTML=un;
  
            newpw(un);
          }
               
           }
       }
       
       
       
   }; 
    
   
    
    
}


function newpw(un){
    

   
    
   var req= new XMLHttpRequest();
   req.open("GET","new_pw.php?un="+un,true);

   req.send();
    
    req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText;
              document.getElementById("up_pw").innerHTML=res;
              
               
           }
       }
       
       
       
   };    
    
}

function seach_odercu(){
    
   
   
   var req= new XMLHttpRequest();
   req.open("GET","search_cus_odr.php",true);
   req.send();
    
   req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText;
              document.getElementById("or_list").innerHTML=res;
              
               
           }
       }
       
       
       
   }; 
    

    
}

function seach_oder(){
    
   
   
   var req= new XMLHttpRequest();
   req.open("GET","sea_oder.php",true);
   req.send();
    
   req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText;
              document.getElementById("or_list").innerHTML=res;
              
               
           }
       }
       
       
       
   }; 
    

    
}


function load_odercu(){
    
    
   
   var req= new XMLHttpRequest();
   req.open("GET","cus_pending_oder.php",true);
   req.send();
    
   req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText.trim();
              if(res==="0"){
                  //window.header('location:../index.php');
               window.top.location="../index.php";  
              }else{
              document.getElementById("or_list").innerHTML=res;
          }
               
           }
       }
       
       
       
   }; 
    

    
}

function load_oder(){
    
    
   
   var req= new XMLHttpRequest();
   req.open("GET","save_cat.php",true);
   req.send();
    
   req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText.trim();
              if(res==="0"){
                  //window.header('location:../index.php');
               window.top.location="../index.php";  
              }else{
              document.getElementById("or_list").innerHTML=res;
          }
               
           }
       }
       
       
       
   }; 
    

    
}

function load_car(){
    
    
   
   var req= new XMLHttpRequest();
   req.open("GET","pop_cart.php",true);
   req.send();
    
   req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText;
              document.getElementById("cari_lo").innerHTML=res;
              
               
           }
       }
       
       
       
   }; 
    

    
}

function offer_page(){
   
   
   var req= new XMLHttpRequest();
   req.open("POST","offer_page.php",true);
    req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
   req.send();
    
   req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
               
              var res=req.responseText.trim();
              if(res==="0"){
                  window.top.location='../index.php';
              }else{
              document.getElementById("cat_load").innerHTML=res;
          }
           }
       }
       
       
       
   }; 
    

    
}

function load_all_items_nev(name){
   
    var para="id="+name;
   var req= new XMLHttpRequest();
   req.open("POST","item.php",true);
    req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
   req.send(para);
    
   req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
               
              var res=req.responseText.trim();
              if(res==="0"){
                  window.top.location='../index.php';
              }else{
              document.getElementById("cat_load").innerHTML=res;
          }
           }
       }
       
       
       
   }; 
    

    
}

function load_all_items(){
    
    var id=   document.getElementById("agileinfo-nav_search").value;
    var para="id="+id;
   var req= new XMLHttpRequest();
   req.open("POST","item.php",true);
    req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
   req.send(para);
    
   req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
               
              var res=req.responseText.trim();
              if(res==="0"){
                  window.top.location='../index.php';
              }else{
              document.getElementById("cat_load").innerHTML=res;
          }
           }
       }
       
       
       
   }; 
    

    
}

function loadall_items_des(){
    
    var id=   document.getElementById("Pro_name").value;
    var para="id1="+id;
   var req= new XMLHttpRequest();
   req.open("POST","sea_description.php",true);
    req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
   req.send(para);
    
   req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText.trim();
              if(res==="0"){
                  window.top.location='index.php';
              }else{
              document.getElementById("cat_load").innerHTML=res;
          }
               
           }
       }
       
       
       
   }; 
    

    
}

function load_checkout(){
    
    
   
   var req= new XMLHttpRequest();
   req.open("GET","checkout.php",true);
   req.send();
    
   req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText;
              document.getElementById("fully").innerHTML=res;
              
               
           }
       }
       
       
       
   }; 
    

    
}

function contact(){
    
    
   
   var req= new XMLHttpRequest();
   req.open("GET","contact.php",true);
   req.send();
    
   req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText;
              document.getElementById("fully").innerHTML=res;
              
               
           }
       }
       
       
       
   }; 
    

    
}


function about(){
    
    
   
   var req= new XMLHttpRequest();
   req.open("GET","about.php",true);
   req.send();
    
   req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText;
              document.getElementById("fully").innerHTML=res;
              
               
           }
       }
       
       
       
   }; 
    

    
}





function item_add_load(){
    
   
   
   var req= new XMLHttpRequest();
   req.open("GET","item_add.php",true);
   req.send();
    
   req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText;
              document.getElementById("or_list").innerHTML=res;
              
               
           }
       }
       
       
       
   }; 
    

    
}


function pending_customerload(){
    
   
   
   var req= new XMLHttpRequest();
   req.open("GET","pending_customer.php",true);
   req.send();
    
   req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText;
              document.getElementById("or_list").innerHTML=res;
              
               
           }
       }
       
       
       
   }; 
    

    
}

function priceset_load(){
    
   
   
   var req= new XMLHttpRequest();
   req.open("GET","set_price.php",true);
   req.send();
    
   req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText;
              document.getElementById("or_list").innerHTML=res;
              
               
           }
       }
       
       
       
   }; 
    

    
}

function set_offer_load(){
    
   
   
   var req= new XMLHttpRequest();
   req.open("GET","set_offer.php",true);
   req.send();
    
   req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText;
              document.getElementById("or_list").innerHTML=res;
              
               
           }
       }
       
       
       
   }; 
    

    
}
////////////////////////////////////////////////////

function category_add(){
    
    
   
   var req= new XMLHttpRequest();

   req.open("GET","category_add.php",true);
   req.send();
       
   req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
          
              var res=req.responseText;
              document.getElementById("or_list").innerHTML=res;
              
               
           }
       }
       
       
       
   }; 
    

    
}

function save_catogery(){
   
  
    var name=document.getElementById("cat_name").value;
   
  
    
   
   var para="name="+name;
   
    
   var req= new XMLHttpRequest();
   req.open("POST","catogory_add.php",true);
    req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    req.send(para);  
   
    
       req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText;
               
              if(res === "0"){
               
                
                  document.getElementById("msg11").innerHTML="Fill empty fields";
                    
              }else if(res === "1"){
                 document.getElementById("msg11").innerHTML="This Category already added";  
                  
              }else if(res === "2"){
                  
                 category_add();
              }
               
           }
       }
        
       
   }; 
    
}

function loging(){
   
   
    var id=document.getElementById("cu_id").value;
    var pw=document.getElementById("cu_pw").value;
   
   
   
   
   var para="id="+id+"&pw="+pw;
   
    
   var req= new XMLHttpRequest();
   req.open("POST","loging_load.php",true);
    req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    req.send(para);  
   
    
       req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText.trim();
             

              if(res === "0"){
               
   
             window.top.location='index.php';
                 
                    
              }else if(res === "1"){
                      
                 document.getElementById("wor_id").innerHTML="<h3 style='color: red;' >User name or Password incorrect</h3>";  
                  
              }else if(res === "2"){
                  
           document.getElementById("wor_id").innerHTML="<h3 style='color: red;' >Please fill username and password</h3>";  
   
              }
               
           }
       }
        
       
   }; 
    
}

function loging1(){
   
   
    var id=document.getElementById("cu1_id").value;
    var pw=document.getElementById("cu1_pw").value;
   
  
   
   
   var para="id="+id+"&pw="+pw;
   
    
   var req= new XMLHttpRequest();
   req.open("POST","loging_load.php",true);
    req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    req.send(para);  
   
    
       req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText.trim();
             

              if(res === "0"){
               
             window.top.location='index.php';
                 
                    
              }else if(res === "1"){
                      
                 document.getElementById("wor_id").innerHTML="<h3 style='color: red;' >User name or Password incorrect</h3>";  
                  
              }else if(res === "2"){
                  
           document.getElementById("wor_id").innerHTML="<h3 style='color: red;' >Please fill username and password</h3>";  
   
              }
               
           }
       }
        
       
   }; 
    
}

function add_item(ty){
   
    var it_id=document.getElementById("it_id").value;
   
    var it_des=document.getElementById("it_des").value;
    var it_cat=document.getElementById("it_ca").value;


 
   var para="it_id="+it_id+"&it_des="+it_des+"&it_cat="+it_cat+"&ty="+ty;
   
     
   var req= new XMLHttpRequest();
   req.open("POST","save_item.php",true);
    req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    req.send(para);  
   
      
       req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText.trim();
            
              if(res === "0"){
               
                
                  document.getElementById("msg11").innerHTML="Fill empty fields";
                    
              }else if(res === "1"){
                 
                 document.getElementById("msg11").innerHTML="This Income already added";  
                  
              }else if(res === "2"){
                  
               
               item_add_load();
                 
              }else if(res === "3"){
                  
                    document.getElementById("msg11").innerHTML="This Income not register";  
              }
               
           }
       }
        
       
   }; 
    
} 



function itm_list_view(){
    
 var to=document.getElementById("dateTo").value;
            var from=document.getElementById("dateFrom").value;
            
            var para="to="+to+"&from="+from;
   
   var req= new XMLHttpRequest();
   req.open("GET","item_table.php?"+para,true);
   req.send();
    
   req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText;
              document.getElementById("tabnle_it").innerHTML=res;
              
               
           }
       }
       
       
       
   }; 
    

    
}

function edit_item(  id,  ty){
  var id1=id; 
    
  
    var para="id="+id1+"&ty="+ty;
   
    
   var req= new XMLHttpRequest();
   req.open("POST","item_update.php",true);
    req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    req.send(para);  
   
  req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText.trim();
               
if(res==="1"){
    
 item_add_load();   
}
        
                var us1=JSON.parse(res);
                
               
                    document.getElementById("it_id").value = us1[0];
                     
   
    document.getElementById("it_des").value=us1[1];
   document.getElementById("it_ca").value= us1[3];
   document.getElementById("it_ty").value= us1[2];
   document.getElementById("it_im").value= us1[4];
                
                     
                     
                    

           }
       }
        
       
   }; 
    
}

function load_itemdata(){
  var id1=document.getElementById("pri_id").value; 
    
    
    var para="id="+id1;
   
    
   var req= new XMLHttpRequest();
   req.open("POST","load_item_data.php",true);
    req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    req.send(para);  
   
  req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText.trim();
               
        
                var us1=JSON.parse(res);
                
             
                
               
                    document.getElementById("pri_id").value = us1[0];
                     
   
    document.getElementById("pri_des").value=us1[1];
   document.getElementById("pri_cat").value= us1[3];
   document.getElementById("pri_ty").value= us1[2];
   document.getElementById("pri_ac").value= us1[4];
   document.getElementById("pri_sel").value= us1[5];
                
                     
                     
                    

           }
       }
        
       
   }; 
    
}

function save_price(ty){
   
    var pri_id=document.getElementById("pri_id").value;
  
    var pri_ca=document.getElementById("pri_ca").value;
    var pri_amount=document.getElementById("pri_amou").value;
  

 
  
   
  
  
   
   var para="pri_id="+pri_id+"&pri_ca="+pri_ca+"&pri_amount="+pri_amount+"&ty="+ty;
   
    
   var req= new XMLHttpRequest();
   req.open("POST","save_price.php",true);
    req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    req.send(para);  
   
      
       req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText.trim();
            
              if(res === "0"){
               
                
                  document.getElementById("msg11").innerHTML="Fill empty fields";
                    
              }else if(res === "1"){
                 
                 document.getElementById("msg11").innerHTML="This Expense already added";  
                  
              }else if(res === "2"){
               
               priceset_load();
                 
              }else if(res === "3"){
                  
                    document.getElementById("msg11").innerHTML="This Expense not register";  
              }
               
           }
       }
        
       
   }; 
    
} 

function edit_price(  id){
  var id1=id; 
    
    
    var para="id="+id1;
   
    
   var req= new XMLHttpRequest();
   req.open("POST","load_item_data.php",true);
    req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    req.send(para);  
   
  req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText.trim();
               
        
                var us1=JSON.parse(res);
                
             
                
               
                    document.getElementById("pri_id").value = us1[0];
                     
   
    document.getElementById("pri_des").value=us1[1];
   document.getElementById("pri_cat").value= us1[3];
   document.getElementById("pri_ty").value= us1[2];
   document.getElementById("pri_ac").value= us1[4];
   document.getElementById("pri_sel").value= us1[5];
                
                     
                     
                    

           }
       }
        
       
   }; 
    
    
}

function price_list_view(){
    
 var type=document.getElementById("sear_pr_it").value;
            var text=document.getElementById("sear_pr").value;
            
            var para="type="+type+"&text="+text;
   
   var req= new XMLHttpRequest();
   req.open("GET","price_table.php?"+para,true);
   req.send();
    
   req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText;
              document.getElementById("tabnle_it").innerHTML=res;
              
               
           }
       }
       
       
       
   }; 
    

    
}

function add_cart(it_id,cus_id){
    

            
            var para="it_id="+it_id+"&cus_id="+cus_id;
   
   var req= new XMLHttpRequest();
   req.open("POST","save_cart.php",true);
   req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
   req.send(para);
    
  
     req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText.trim();
              
            if(res==="0"){window.top.location='index.php';}else{
                
             load_car();     
            }
               
           }
       }
       
       
       
   }; 
    

    
}

function remo_item(it_id,cus_id){
    

            
            var para="it_id="+it_id+"&cus_id="+cus_id;
   
   var req= new XMLHttpRequest();
   req.open("POST","remove_item.php",true);
   req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
   req.send(para);
    
  
     req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText.trim();
              
            if(res==="0"){window.top.location='index.php';}else{
              load_car();  
            }
               
           }
       }
       
       
       
   }; 
    

    
}

function send_oder(sub,ty){
   
    
var sub = sub;
 
            
            var para="sub="+sub+"&ty="+ty;
   
   var req= new XMLHttpRequest();
   req.open("POST","send_oder.php",true);
   req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
   req.send(para);
    
  
     req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText.trim();
              
            if(res==="0"){window.top.location='index.php';}else{
             
            }
               
           }
       }
       
       
       
   }; 
    

    
}

function change_oder(ty,su){
   
     var para="or_id="+su+"&ty="+ty;
   var req= new XMLHttpRequest();
   req.open("POST","update_oder.php",true);
   req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
   req.send(para);
    
  
     req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText.trim();
              
            if(res==="0"){window.top.location='WP-dashboard.php';}else{
             
            }
               
           }
       }
       
       
       
   }; 
    

    
}

function oder_filter(){
    
 var type=document.getElementById("sear_ty_or").value;
            var text=document.getElementById("sear_or").value;
            
            var para="type="+type+"&text="+text;
   
   var req= new XMLHttpRequest();
   req.open("GET","filter_oder.php?"+para,true);
   req.send();
    
   req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText;
              document.getElementById("filter_oder").innerHTML=res;
              
               
           }
       }
       
       
       
   }; 
    

    
}


function oder_filtercu(){
    
 var type=document.getElementById("sear_ty_or").value;
            var text=document.getElementById("sear_or").value;
            
            var para="type="+type+"&text="+text;
   
   var req= new XMLHttpRequest();
   req.open("GET","filter_cus_oder.php?"+para,true);
   req.send();
    
   req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText;
              document.getElementById("filter_oder").innerHTML=res;
              
               
           }
       }
       
       
       
   }; 
    

    
}

function save_customer(ty){
    
    var cu_id=document.getElementById("cu_id2").value;
    var cu_name=document.getElementById("cu_name").value;
    var cu_mobile=document.getElementById("cu_mobile").value;
    var cu_address=document.getElementById("cu_address").value;
    var cu_email=document.getElementById("cu_email").value;
    var cu_pw1=document.getElementById("cu_pw1").value;
    var cu_pw2=document.getElementById("cu_pw2").value;
  

 
  
   
  
  
   
   var para="cu_id="+cu_id+"&cu_name="+cu_name+"&cu_mobile="+cu_mobile+"&cu_address="+cu_address+"&cu_email="+cu_email+"&ty="+ty+"&cu_pw1="+cu_pw1+"&cu_pw2="+cu_pw2;
   
    
   var req= new XMLHttpRequest();
   req.open("POST","save_register.php",true);
    req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    req.send(para);  
   
      
       req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText.trim();
            
              if(res === "0"){
               
                
                  document.getElementById("msg11").innerHTML="Fill empty fields";
                    
              }else if(res === "1"){
                 
                 document.getElementById("msg11").innerHTML="Already you have account.";  
                  
              }else if(res === "2"){
              
               window.top.location='index.php';
                 
              }else if(res === "3"){
                  
                    document.getElementById("msg11").innerHTML="You not register";  
              }else if(res === "4"){
                  
                    document.getElementById("msg11").innerHTML="Passwords not equal";  
              }
               
           }
       }
        
       
   }; 
    
} 



function load_offer_data(){
  var id1=document.getElementById("pri_id").value; 
    
    
    var para="id="+id1;
   
    
   var req= new XMLHttpRequest();
   req.open("POST","offer_item_load.php",true);
    req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    req.send(para);  
   
  req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText.trim();
               
        
                var us1=JSON.parse(res);
                
             
                
               
                    document.getElementById("pri_id").value = us1[0];
                     
   
    document.getElementById("pri_des").value=us1[1];
   document.getElementById("pri_cat").value= us1[3];
   document.getElementById("pri_ty").value= us1[2];

   document.getElementById("pri_sel").value= us1[4];
                
                     
                     
                    

           }
       }
        
       
   }; 
    
}

function save_offers(ty){
   
    var pri_id=document.getElementById("pri_id").value;
  
  
    var pri_sel=document.getElementById("pri_sel").value;
  

 
  
   
  
  
   
   var para="pri_id="+pri_id+"&pri_sel="+pri_sel+"&ty="+ty;
   
    
   var req= new XMLHttpRequest();
   req.open("POST","save_offer.php",true);
    req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    req.send(para);  
   
      
       req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText.trim();
                alert(res);
              if(res === "0"){
               
                
                  document.getElementById("msg112").innerHTML="Fill empty fields";
                    
              }else if(res === "1"){
                 
                 document.getElementById("msg112").innerHTML="This Item  already added Offer";  
                  
              }else if(res === "2"){
               
               set_offer_load();
                 
              }else if(res === "3"){
                  
                    document.getElementById("msg112").innerHTML="This Item not set Offer";  
              }
               
           }
       }
        
       
   }; 
    
} 

function offer_list(){
    
 var to=document.getElementById("dateTo").value;
            var from=document.getElementById("dateFrom").value;
            
            var para="to="+to+"&from="+from;
   
   var req= new XMLHttpRequest();
   req.open("GET","offer_table.php?"+para,true);
   req.send();
    
   req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
               
              var res=req.responseText;
              document.getElementById("tabnle_it").innerHTML=res;
              
               
           }
       }
       
       
       
   }; 
    

    
}

