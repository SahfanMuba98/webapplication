
<!DOCTYPE html>
<?php
session_start();
include("Connect.php");

?>
<html>

<head>
	<title>API APIMA</title>
	
	
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--//tags -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/font-awesome.css" rel="stylesheet">
	<!--pop-up-box-->
	<link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all" />
	<!--//pop-up-box-->
	<!-- price range -->
	<link rel="stylesheet" type="text/css" href="css/jquery-ui1.css">
	<!-- fonts -->
	
        
        <style>
            
       


.minicartk-footer {
    text-align: center;
    margin-right: -10px;
    position: relative;
	width: 600px;
}

 .minicartk-subtotal {
     padding-left: 25px;
	bottom: -17px ;
        padding-left: 0px ;
        bottom: -18px; 
        font-size: 20px;
        font-weight: bold;
    }
    
    .minicartk-submit {
    color: #fff;
    background: #1accfd ;
    padding:0px;
    font-size: 16px;
    text-align: center;
    letter-spacing: 1px;
    text-decoration: none;
    -webkit-transition: 0.5s all;
    -moz-transition: 0.5s all;
    -o-transition: 0.5s all;
    -ms-transition: 0.5s all;
    transition: 0.5s all;
    bottom: -25px!important;
    right: 0 !important;
    border: 1px solid #1accfd!important;
    border-radius: 0px!important;
    text-shadow: none!important;
     min-width: 133px;
     min-height: 50px;
        
        padding:0;
       
}
        </style>  

</head>

<body> 
    
 
   
    <div class="header-most-top" >
    <p style="background-color: #000033;">Empowering Communities Through Shared Purpose</p>
</div>
    <div class="header-bot">
    <div class="header-bot_inner_wthreeinfo_header_mid">
        <!-- header-bot-->
        <div class="col-md-4 logo_agile">
            <h1>
                <a href="index.php">
                    <span>A</span>PI
                    <span>A</span>PIMA
                    
                    
                </a>
            </h1>
        </div>
        
    
        <!-- header-bot -->
        <div class="col-md-8 header">
            <!-- header lists -->
            <ul>
               
                <li>
                    <?php
                    if( isset($_SESSION['id'])){
    

      

                    $ses=$_SESSION['id']; 
                    if($ses==="2020"){
                        
                        echo '<a href="admin/WP-dashboard.php">
                        <span class="fa fa-truck" aria-hidden="true"></span>Dashboard</a>';   
                    }else{
                        echo '<a href="admin/WP-dashboard.php">
                        <span class="fa fa-truck" aria-hidden="true"></span>Dashboard</a>';
                    }}else{
                        
                        $ses='0';
                    }
                    
                    ?>
                    
                </li>
                <li>
                    <span class="fa fa-phone" aria-hidden="true"></span> 011 715 5513
                </li>
                <li>
                    <a href="#" data-toggle="modal" data-target="#myModal1">
                        <span class="fa fa-unlock-alt" aria-hidden="true"></span> Sign In </a>
                </li>
                <li>
                    <a href="#" data-toggle="modal" data-target="#myModal2">
                        <span class="fa fa-pencil-square-o" aria-hidden="true"></span> Sign Up </a>
                </li>
            </ul>
            <!-- //header lists -->
            <!-- search -->
            
            <!-- //search -->
            <!-- cart details -->
            
            <!-- //cart details -->
            <div class="clearfix"></div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
      
    <?php 
   
    
if( isset($_SESSION['id'])){
    
 $ses_id=$_SESSION['id']; 
      
}else{
   $ses_id='0'; 
   echo ' 
     <div class="container" >

 <div class="modal fade" id="home-modal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
       <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
        <div class="modal-body">
 <div class="modal-body modal-body-sub_agile">
                <div class="main-mailposi">
                    <span class="fa fa-envelope-o" aria-hidden="true"></span>
                </div>
                <div class="modal_body_left modal_body_left1">
                    <h3 class="agileinfo_sign">Sign In </h3>
                    <p>Do not have an account?
                        <a href="#" data-toggle="modal" data-target="#myModal2">
                            Sign Up Now</a>
                    </p>
                  
                        <div class="styled-input agile-styled-input-top">
                            <input type="text" placeholder="User Name" id="cu_id" required="">
                        </div>
                        <div class="styled-input">
                            <input type="password" placeholder="Password" id="cu_pw" required="">
                        </div>
                        <div id="wor_id"></div>
                        <input onclick="loging();" type="submit" value="Sign In">
                        
<p>
                        <a href="admin/forget.php">
                            Forget Password</a>
                    </p>
                    
                    <div class="clearfix"></div>
                </div>                </div>
           
    </div>
  </div>
  
</div>

 


  
</div>';    
}
    
    ?> 
   
        
        <div class="modal fade" id="myModal3" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
         <div id="cari_lo">
        
    </div> 
    </div> 
    </div> 
    </div> 
    
</div>
    
    <div class="modal fade" id="myModal1" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body modal-body-sub_agile">
                <div class="main-mailposi">
                    <span class="fa fa-envelope-o" aria-hidden="true"></span>
                </div>
                <div class="modal_body_left modal_body_left1">
                    <h3 class="agileinfo_sign">Sign In </h3>
                    <p>
                        Sign In now, Don't have an account?
                        <a href="#" data-toggle="modal" data-target="#myModal2">
                            Sign Up Now</a>
                    </p>
                  
                        <div class="styled-input agile-styled-input-top">
                            <input type="text" placeholder="User Name"  id="cu1_id" required="">
                        </div>
                        <div class="styled-input">
                            <input type="password" placeholder="Password" id="cu1_pw" required="">
                        </div>
                    <div id="wor_id"></div>
                        <input onclick="loging1();" type="submit" value="Sign In">
                 <p>
                     <a href="admin/forget.php" >
                            Forget Password</a>
                    </p>
                    <div class="clearfix"></div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <!-- //Modal content-->
    </div>
</div>
   
    <div class="modal fade" id="myModal2" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body modal-body-sub_agile">
                <div class="main-mailposi">
                    <span class="fa fa-envelope-o" aria-hidden="true"></span>
                </div>
                <div class="modal_body_left modal_body_left1">
                    <h3 class="agileinfo_sign">Sign Up</h3>
                   
                  
                        <div class="styled-input agile-styled-input-top">
                            <input type="text" placeholder="NIC Number(Number Only)" id="cu_id2" required="">
                             
                        </div>
                        <div class="styled-input">
                            <input type="text" placeholder="Full Name" id="cu_name" required="">
                        </div>
                        <div class="styled-input">
                            <input type="text" placeholder="Mobile Number" id="cu_mobile" required="">
                        </div>
                        <div class="styled-input">
                            <input type="text" placeholder="Address" id="cu_address" required="">
                        </div>
                        <div class="styled-input">
                            <input type="email" placeholder="E-mail" id="cu_email" required="">
                        </div>
                        <div class="styled-input">
                            <input type="password" placeholder="Password" name="password" id="cu_pw1" required="">
                        </div>
                        <div class="styled-input">
                            <input type="password" placeholder="Confirm Password" name="Confirm Password" id="cu_pw2" required="">
                        </div>
                    <div id="msg11" style="color: red;"></div>
                    <input  onclick="save_customer('0');" type="submit" value="Sign Up">
                  
                    <p>
                        <a>By clicking register, I agree to your terms</a>
                    </p>
                </div>
            </div>
        </div>
      
    </div>
</div>
    
    <div class="ban-top">
    <div class="container">
       
        <div class="top_nav_left">
            <nav class="navbar navbar-default">
                <div class="container-fluid">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"
                                aria-expanded="false">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>
                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse menu--shylock" id="bs-example-navbar-collapse-1">
                        <ul class="nav navbar-nav menu__list">
                            <li class="active">
                                <a class="nav-stylehead" href="index.php">Home
                                    <span class="sr-only">(current)</span>
                                </a>
                            </li>
                            <li class="">
                                <a class="nav-stylehead" onclick="about();" style="cursor: pointer;" >About Us</a>
                            </li>
                            
                            
                       
                            <li class="">
                                <a class="nav-stylehead" onclick="contact();" style="cursor: pointer;" >Contact</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    </div>
</div>
    
    <!-- //navigation -->
	<!-- banner -->
        <div id="fully">
        
	<div id="myCarousel" class="carousel slide" data-ride="carousel">
		<!-- Indicators-->
		<ol class="carousel-indicators">
			<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
			<li data-target="#myCarousel" data-slide-to="1" class=""></li>
			<li data-target="#myCarousel" data-slide-to="2" class=""></li>
			<li data-target="#myCarousel" data-slide-to="3" class=""></li>
		</ol>
		<div class="carousel-inner" role="listbox">
                    <div class="item active" >
				<div class="container">
					<div class="carousel-caption">
						<h3>Together   
							<span>Building</span>
						</h3>
						<p>a Brighter
							 Future</p>
                                                <a class="button2" style="cursor: pointer;" onclick="about();">Read Now </a>
					</div>
				</div>
			</div>
			<div class="item item2">
				<div class="container">
					<div class="carousel-caption">
						<h3>Empowering    
							<span>Communities</span>
						</h3>
						<p>Through
							<span>Shared</span> Purpose</p>
                                                <a class="button2" style="cursor: pointer;" onclick="about();">Read Now </a>
					</div>
				</div>
			</div>
			<div class="item item3">
				<div class="container">
					<div class="carousel-caption">
						<h3>Strengthening  
							<span>Lives,</span>
						</h3>
						<p>Inspiring Positive
							<span>Change</span>
						</p>
                                                <a class="button2" style="cursor: pointer;" onclick="about();">Read Now </a>
					</div>
				</div>
			</div>
			<div class="item item4">
				<div class="container">
					<div class="carousel-caption">
						<h3>Unity,   
							<span>Support,</span>
						</h3>
						<p>and Sustainable
							 Progress</p>
						<a class="button2" style="cursor: pointer;" onclick="about();">Read Now </a>
					</div>
				</div>
			</div>
		</div>
		<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
			<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
			<span class="sr-only">Previous</span>
		</a>
		<a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
			<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
			<span class="sr-only">Next</span>
		</a>
	</div>
	<!-- //banner -->

	<!-- top Products -->
	<div class="ads-grid">
		<div class="container">
			<!-- tittle heading -->
			
			<!-- //tittle heading -->
			<!-- product left -->
			
			<!-- //product left -->
			<!-- product right -->
                        
                        <div id="cat_load">
			<div class="agileinfo-ads-display col-md-9">
				<div class="wrapper">
					<!-- first section (nuts) -->
					
					<!-- //first section (nuts) -->
					<!-- second section (nuts special) -->
					<div class="product-sec1 product-sec2">
						<div class="col-xs-7 effect-bg">
							<h3 class="">Inspiring Hope, Creating Lasting Change</h3>
							
						</div>
						<h3 class="w3l-nut-middle">Action and Growth</h3>
						<div class="col-xs-5 bg-right-nut">
							<img src="images/nut1.png" alt="">
						</div>
						<div class="clearfix"></div>
					</div>
					
					
				</div>
			</div>
			
		</div>
                        
                        </div>
	</div>
	
	
	
        </div>
        
         
        
        <!-- footer -->
	<footer>
		<div class="container">
			<!-- footer first section -->
			
			<!-- //footer third section -->
			<!-- footer fourth section (text) -->
			<div class="agile-sometext">
				<div class="sub-some">
					<h5 style="color: #000033;">Vision</h5>
					<p>"To empower communities through sustainable development, fostering self-reliance, unity, and growth to build a brighter future for all."</p>
				</div>
				<div class="sub-some">
					<h5 style="color: #000033;">Mission</h5>
					<p>"Our mission is to uplift and empower individuals and communities by providing resources, support, and education that foster sustainable development, self-sufficiency, and collective well-being."</p>
				</div>
				
				
			</div>
			<!-- //footer fourth section (text) -->
		</div>
	</footer>
	<!-- //footer -->
        
        <!-- copyright -->
        <div class="copy-right" style="background-color: #000033;"
		<div class="container">
			<p>© 2024 API APIMA. All rights reserved | Design by
				<a href="http://hashcodeinnovations.com">HashCode Innovations</a>
			</p>
		</div>
	 <!-- Messenger Chat Plugin Code -->
    <div id="fb-root"></div>

    <!-- Your Chat Plugin code -->
    <div id="fb-customer-chat" class="fb-customerchat">
    </div>

   
        
        <script src="js/jquery-2.1.4.min.js"></script>
        <script src="js/jquery.magnific-popup.js"></script>
        <script>
		$(document).ready(function () {
			$('.popup-with-zoom-anim').magnificPopup({
				type: 'inline',
				fixedContentPos: false,
				fixedBgPos: true,
				overflowY: 'auto',
				closeBtnInside: true,
				preloader: false,
				midClick: true,
				removalDelay: 300,
				mainClass: 'my-mfp-zoom-in'
			});

		});
	</script>
        <script src="js/minicart.js"></script>
        <script>
		paypalm.minicartk.render(); //use only unique class names other than paypalm.minicartk.Also Replace same class name in css and minicart.min.js

		paypalm.minicartk.cart.on('checkout', function (evt) {
			var items = this.items(),
				len = items.length,
				total = 0,
				i;

			// Count the number of each item in the cart
			for (i = 0; i < len; i++) {
				total += items[i].get('quantity');
			}

			if (total < 2) {
				alert('The minimum order quantity is 2. Please add more to your shopping cart before checking out');
				evt.preventDefault();
			}
		});
	</script>
        <script src="js/jquery-ui.js"></script>
        <script>
		//<![CDATA[ 
		$(window).load(function () {
			$("#slider-range").slider({
				range: true,
				min: 0,
				max: 9000,
				values: [50, 6000],
				slide: function (event, ui) {
					$("#amount").val("Ru." + ui.values[0] + " - Ru." + ui.values[1]);
				}
			});
			$("#amount").val("" + $("#slider-range").slider("values", 0) + " - Ru." + $("#slider-range").slider("values", 1));

		}); //]]>
	</script>
        <script src="js/jquery.flexisel.js"></script>
        	<script>
		$(window).load(function () {
			$("#flexiselDemo1").flexisel({
				visibleItems: 3,
				animationSpeed: 1000,
				autoPlay: true,
				autoPlaySpeed: 3000,
				pauseOnHover: true,
				enableResponsiveBreakpoints: true,
				responsiveBreakpoints: {
					portrait: {
						changePoint: 480,
						visibleItems: 1
					},
					landscape: {
						changePoint: 640,
						visibleItems: 2
					},
					tablet: {
						changePoint: 768,
						visibleItems: 2
					}
				}
			});

		});
	</script>
        
    <script src="js/SmoothScroll.min.js"></script>
	
	<script src="js/move-top.js"></script>
	<script src="js/easing.js"></script>
	<script>
		jQuery(document).ready(function ($) {
			$(".scroll").click(function (event) {
				event.preventDefault();

				$('html,body').animate({
					scrollTop: $(this.hash).offset().top
				}, 1000);
			});
		});
	</script>
	
	<script>
		$(document).ready(function () {
			
			$().UItoTop({
				easingType: 'easeOutQuart'
			});

		});
	</script>
	
	<script src="js/bootstrap.js"></script>
        <script src="js/reqest.js" >
        
        
        
        </script>
	
       
    
 <script src="js/reqest.js"></script>
 <script>er
 
function loging_load() {

    var req= new XMLHttpRequest();
   req.open("GET","loging_load.php",true);
   req.send();
    
   req.onreadystatechange=function (){
       if(req.readyState===4){
           
           if(req.status===200){
              
              var res=req.responseText;
              document.getElementById("log").innerHTML=res;
              
             
           }
       }
       
       
       
   }; 
    

}


 </script>
 
 
 
    
<style type="text/css">.modal-header{padding:15px;border-bottom:none;font-family:'Open Sans',sans-serif;color:#0080c7;font-size:20px}}

.modal-body {position:relative;padding:0;padding:15px;font-family:'Open Sans',sans-serif}.btn-default,.btn-default:hover{font-size:20px;color:#5a5a5a;background-color:#fff;border-color:#fff}.modal-dialog{overflow:auto}.modal{z-index:100002}@media (max-width:768px) and (orientation:landscape){#home-modal{padding-top:75px}.modal{z-index:100000}}@media (max-width:768px) and (orientation:portrait){#home-modal{padding-top:75px}}@media (min-width:768px){.modal-dialog{width:750px}}</style>

 
  <script type="text/javascript">$(window).load(function(){$('#home-modal').modal('show');$('#home-modal').modal({backdrop:'static',keyboard:false})})</script>

 <!-- Messenger Chat Plugin Code -->
    <div id="fb-root"></div>

    <!-- Your Chat Plugin code -->
    <div id="fb-customer-chat" class="fb-customerchat">
    </div>


</body>

</html>

