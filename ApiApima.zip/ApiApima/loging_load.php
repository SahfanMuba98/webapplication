

<?php
session_start();
include("Connect.php");

 $id = $_POST["id"];

 if($_POST["id"]=== "" || $_POST["pw"]=== ""){
    echo "2";     
     
 }else{
     
            $msg ="SELECT * FROM user where username = '".$_POST["id"]."' and password='".$_POST["pw"]."' ";
                    $result=$con->query($msg);
                    if ( mysqli_fetch_array($result)===null){
 echo "1";
                        
                    }else{
                     $_SESSION["id"]=$id; 
            
            echo '0';   
                        
                    }
 }
 
?>